package com.ite.ics26011_altproj

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.sleep(2000) // Not recommended; use Splash API instead
        installSplashScreen()
        enableEdgeToEdge()
        setContentView(R.layout.lounges)

        // Handle window insets for the main layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)

            // Return the insets object as required
            insets
        }

        // Set OnClickListener for the hamburger icon
        val backHomeButton: Button = findViewById(R.id.backhome)



        // Set the click listener

        val logo: ImageView = findViewById(R.id.logo)
        val hamburgerIcon: ImageButton = findViewById(R.id.hamburger_icon)
        hamburgerIcon.setOnClickListener {
            val intent = Intent(this, HamburgerActivity::class.java)
            startActivity(intent)

        }



        // Set a click listener on the ImageView
        logo.setOnClickListener {
            // Navigate to DashboardActivity when clicked
            val intent = Intent(this, Dashboard::class.java)
            startActivity(intent)
        }

        backHomeButton.setOnClickListener {
            val intent = Intent(this, Dashboard::class.java)
            startActivity(intent)
        }








    }
}
