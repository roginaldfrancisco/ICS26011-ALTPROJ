package com.ite.ics26011_altproj


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class Dashboard:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard) // Link to hamburger.xml , this should go first


        val logo: ImageView = findViewById(R.id.logo)
        val hamburgerIcon: ImageButton = findViewById(R.id.hamburger_icon)

        val viewlounges: Button = findViewById(R.id.viewlounges)
        val viewrestaurants: Button = findViewById(R.id.viewrestaurants)
        val viewshops: Button = findViewById(R.id.viewshops)
        val viewairlines: Button = findViewById(R.id.viewairlines)
        val viewdevelopers: Button = findViewById(R.id.viewdevelopers)
        val viewdestinations: Button = findViewById(R.id.viewdestinations)
        hamburgerIcon.setOnClickListener {
            val intent = Intent(this, HamburgerActivity::class.java)
            startActivity(intent)

        }

        logo.setOnClickListener {
            // Navigate to DashboardActivity when clicked
            val intent = Intent(this, Dashboard::class.java)
            startActivity(intent)
        }


        viewdestinations.setOnClickListener {
            val intent = Intent(this, Destinations::class.java)
            startActivity(intent)
        }



        viewlounges.setOnClickListener {
            val intent = Intent(this, Lounges::class.java)
            startActivity(intent)
        }

        viewrestaurants.setOnClickListener {
            val intent = Intent(this, Restaurants::class.java)
            startActivity(intent)
        }

        viewshops.setOnClickListener {
            val intent = Intent(this, Shops::class.java)
            startActivity(intent)
        }

        viewairlines.setOnClickListener {
            val intent = Intent(this, Airlines::class.java)
            startActivity(intent)
        }

        viewdevelopers.setOnClickListener {
            val intent = Intent(this, Developers::class.java)
            startActivity(intent)
        }










    }


}

