package com.ite.ics26011_altproj

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class Airlines:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.airlines)


        val backHomeButton: Button = findViewById(R.id.backhome)



        // Set the click listener

        val logo: ImageView = findViewById(R.id.logo)
        val hamburgerIcon: ImageButton = findViewById(R.id.hamburger_icon)
        hamburgerIcon.setOnClickListener {
            val intent = Intent(this, HamburgerActivity::class.java)
            startActivity(intent)

        }



        // Set a click listener on the ImageView
        logo.setOnClickListener {
            // Navigate to DashboardActivity when clicked
            val intent = Intent(this, Dashboard::class.java)
            startActivity(intent)
        }

        backHomeButton.setOnClickListener {
            val intent = Intent(this, Dashboard::class.java)
            startActivity(intent)
        }


    }



}
