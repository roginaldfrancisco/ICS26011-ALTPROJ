package com.ite.ics26011_altproj
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class HamburgerActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.hamburger) // Link to hamburger.xml
        val logo: ImageView = findViewById(R.id.logo)
        logo.setOnClickListener {
            // Navigate to DashboardActivity when clicked
            val intent = Intent(this, Dashboard::class.java)
            startActivity(intent)
        }


        val viewlounges: Button = findViewById(R.id.viewlounges)
        val viewrestaurants: Button = findViewById(R.id.viewrestaurants)
        val viewshops: Button = findViewById(R.id.viewshops)
        val viewairlines: Button = findViewById(R.id.viewairlines)
        val viewflights: Button = findViewById(R.id.viewflights)
        val viewdestinations: Button = findViewById(R.id.viewdestinations)


        // Set the click listener


        val hamburgerIcon: ImageButton = findViewById(R.id.hamburger_icon)
        hamburgerIcon.setOnClickListener {
            val intent = Intent(this, HamburgerActivity::class.java)
            startActivity(intent)

        }


        viewdestinations.setOnClickListener {
            val intent = Intent(this, Destinations::class.java)
            startActivity(intent)
        }


        viewflights.setOnClickListener {
            val intent = Intent(this, Flights::class.java)
            startActivity(intent)
        }


        viewlounges.setOnClickListener {
            val intent = Intent(this, Lounges::class.java)
            startActivity(intent)
        }

        viewrestaurants.setOnClickListener {
            val intent = Intent(this, Restaurants::class.java)
            startActivity(intent)
        }

        viewshops.setOnClickListener {
            val intent = Intent(this, Shops::class.java)
            startActivity(intent)
        }

        viewairlines.setOnClickListener {
            val intent = Intent(this, Airlines::class.java)
            startActivity(intent)
        }





        // Set a click listener on the ImageView








    }



}
